# 金蝶云·星辰销售订单同步工具 · 使用说明

> 从金蝶云·星辰(开放平台)定时拉取**已审核销售订单**,写入本系统 SQL Server 的
> `bd_so_order`(头表)/`bl_so_order`(行表),销售订单面板(SO_ORDER)直接可见。
> 本文档面向需要在**其他电脑**上部署、测试、运维本工具的项目成员。

## 1. 工作原理

```text
Windows 计划任务(每 5 分钟,隐藏窗口)
  → node sync.mjs
     ① 取 app-token(clientId/clientSecret 签名换取,缓存约 23 小时)
     ② GET /jdy/v2/scm/sal_order        全量拉取已审核单(分页)
     ③ GET /jdy/v2/scm/sal_order_detail 逐单取商品分录
     ④ 字段映射 → 事务写 SQL Server(幂等:按 外部数据ID 去重,行表先删后插)
     ⑤ 日志追加 sync.log
```

- **全量扫描**:不使用接口的 modify 时间窗过滤——**实测该过滤会漏单**
  (窗口内的已审核单据返回 0,2026-09-08 排查记录),改为每次全量拉取+幂等写入,
  正确性靠数据库唯一索引兜底;单据量大时(数千张)请调大任务间隔;
- **幂等**:`bd_so_order.外部数据ID` 存星辰单据 id(唯一索引),重拉/重叠不产生重复单据;
- **限流**:账套级 500 次/分钟(官方),每次运行为"1 次列表 + 每单 1 次详情",注意 maxPages 上限。

## 2. 交付文件清单(本目录)

| 文件 | 作用 | 必需 |
|---|---|---|
| `sync.mjs` | 主脚本:拉取→映射→写库→日志 | ✓ |
| `kingdee-client.mjs` | 星辰 API 客户端:两套签名/token/GET(重试) | ✓ |
| `run-hidden.vbs` | 计划任务隐藏启动器(消除 node 控制台弹窗) | ✓ |
| `config.example.json` | 配置模板(**复制为 config.json 再填**) | ✓ |
| `package.json` / `package-lock.json` | npm 依赖声明(mssql,连接 SQL Server) | ✓ |
| `migrate-add-external-cols.sql` | 数据库幂等迁移:bd_so_order 加 外部数据ID/外部单据号 + 唯一索引 | ✓ |
| `_verify-signature.mjs` | 诊断:离线校验签名算法与官方文档示例值是否一致 | 可选 |
| `README.md` | 本文档 | — |

运行后本目录会自动产生(均不入 git):`config.json`(配置)、`state.json`(token 缓存)、`sync.log`(运行日志)、`node_modules/`(依赖)。

## 3. 前置条件

1. **Node.js ≥ 18**(建议 LTS):https://nodejs.org 下载安装,`node -v` 验证;
2. **SQL Server 可访问**:目标库默认 `HSDZ_MES`,需要一个有 `bd_so_order`/`bl_so_order`
   读写权限的 SQL 账号(本机后端的连接信息见项目 `backend/src/main/resources/application.yml`);
3. **金蝶开放平台凭证** 4 件套(https://open.jdy.com 开发者后台):
   - `clientId`/`clientSecret`:创建应用后,应用详情页"应用凭证"区;
   - `appKey`/`appSecret`:对账套完成授权后获得(沙箱授权在应用详情"沙箱测试"里;
     正式账套走《获取授权信息》文档的授权链接流程);
   - `domain`:IDC 域名,如 `https://tf.jdy.com`(沙箱调用同样可用此域名)。

## 4. 新电脑部署(5 步,约 10 分钟)

> ⚠ 目录位置要求:**路径不要含括号/空格/中文**,推荐 `D:\jdy-sync`。
> (cmd 对括号路径的解析会导致计划任务静默失败,本项目实测踩过)

1. **复制整个目录**到目标机器,如 `D:\jdy-sync\`;
2. **装依赖**(PowerShell 中若 npm 报"禁止运行脚本",改用 `npm.cmd`):
   ```powershell
   cd D:\jdy-sync
   npm.cmd install
   ```
3. **配置**:复制 `config.example.json` → `config.json`,按下表填写:

   | 段 | 字段 | 说明 |
   |---|---|---|
   | kingdee | clientId / clientSecret | 应用凭证(应用级) |
   | kingdee | appKey / appSecret | 账套授权凭证(沙箱或正式,决定能看到哪个账套的数据) |
   | kingdee | domain | IDC 域名,如 https://tf.jdy.com |
   | database | server/port/database | SQL Server 地址与库名(本机默认 localhost:1433/HSDZ_MES) |
   | database | user / password | SQL 账号(如 yinjia) |
   | sync | billStatus | 状态过滤:**空=全部状态(默认)**;C=仅已审核 |
   | sync | pageSize / maxPages | 列表分页大小与最大页数(单次运行保护上限) |

   `config.json` 含密钥口令,**已被 .gitignore 排除,严禁提交或外发**;
4. **数据库迁移**(一次性,幂等可重复):SSMS 连接目标库执行 `migrate-add-external-cols.sql`,
   自检应输出三项 1;
5. **验证三连**(见下节)。

## 5. 验证与运行

```powershell
cd D:\jdy-sync
node sync.mjs --probe      # ① 取token+拉1单+详情并打印映射(不连数据库,零依赖)
node sync.mjs --dry-run    # ② 完整拉取+映射,打印每单结果,不写库
node sync.mjs              # ③ 正式同步(每次全量拉取,幂等写入)
```

预期输出(③,无新单时):

```text
[时间] app-token 就绪(eyJ0eX...)
[时间] 增量窗口: ... → ...(首次运行)
[时间] 列表第 1/1 页,本页 0 条,共 0 条
[时间] 完成:新增 0,更新 0,失败 0
```

退出码:`0` 成功;`2` 部分单据失败(下轮自动重试);`1` 整体失败(看日志首行报错)。

## 6. 注册定时任务(每 5 分钟,无弹窗)

用 **run-hidden.vbs 隐藏启动**(推荐,普通权限即可,前台无任何窗口):

```powershell
$action   = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument '"D:\jdy-sync\run-hidden.vbs"' -WorkingDirectory 'D:\jdy-sync'
$trigger  = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
Register-ScheduledTask -TaskName 'JdySalOrderSync' -Action $action -Trigger $trigger
```

注意:`run-hidden.vbs` 内写死了 node 与脚本路径,换目录/换机器需同步修改其中两处路径。
> 实测要点:任务动作**不要**直接指向 .bat(带括号路径会被 cmd 拦下,LastResult=1 且无输出);
> bat 文件必须 CRLF+ASCII(LF 会被 cmd 错位解析)。

常用运维命令:

```powershell
Start-ScheduledTask JdySalOrderSync      # 立即触发一次
Get-ScheduledTaskInfo JdySalOrderSync    # 看上次结果(0=正常)与下次时间
Unregister-ScheduledTask JdySalOrderSync -Confirm:$false   # 删除任务
```

改频率:删任务后把 `New-TimeSpan -Minutes 5` 改成目标值重新注册。
(可选)要求"用户未登录也运行":管理员权限下把注册命令加上
`-Principal (New-ScheduledTaskPrincipal -UserId "$env:COMPUTERNAME\$env:USERNAME" -LogonType S4U)`。

## 7. 字段映射

| 星辰(详情接口) | 本地 bd_so_order | 说明 |
|---|---|---|
| id | 外部数据ID | 幂等锚点(唯一索引) |
| bill_no | 单据编号 / 外部单据号 | 沿用星辰单号,与本地 SO- 前缀单号天然不冲突 |
| bill_date / remark | 单据日期 / 备注 | |
| customer_number / customer_name | 客户编码 / 客户 | |
| settle_customer_number | 结算客户 | 星辰详情仅返回编码 |
| dept_name / emp_name | 部门 / 业务员 | |
| contact_linkman | 联系人 | 电话/地址为加密敏感字段,不取 |
| bill_status C/Z | 单据状态 已审核/草稿 | 默认拉全部状态,如实映射;只要已审核则 billStatus 设 C |
| auditor_name / audit_time | 审核人 / 审核时间 | |
| 明细最早 delivery_date | 预计交货日期 | 头表无此字段 |

| 星辰 material_entity | 本地 bl_so_order |
|---|---|
| material_number / material_name / material_model | 存货编码 / 存货名称 / 规格型号 |
| qty / unit_name | 数量 / 销售单位 |
| price / cess / tax_price | 单价 / 税率% / 含税单价 |
| amount / all_amount / dis_amount | 金额 / 含税金额 / 折扣金额 |
| delivery_date / inv_qty / comment | 预计交货日期 / 现存量 / 备注 |

品牌/部门负责人/项目星辰无对应字段,置 NULL。写库统一 `asp_user1='jdy-sync'` 留痕;
更新时行表按单据编号先删后插(与头表同一事务)。

**审核状态镜像(MES 显示的关键)**:MES 面板的"单据状态"由工作流注册表 `yj_doc_status`
推导(不看单据表物理列),同步会把星辰状态镜像进去:

| 星辰动作 | yj_doc_status | MES 显示 |
|---|---|---|
| 审核(bill_status=C) | shr/shsj=星辰审核人/审核时间 | 已审核 |
| 弃审(未审核) | shr/shsj 置空 | 草稿 |
| 单据关闭(S/H) | stopped=Y | 已中止 |

⚠ 同步单据以星辰为唯一事实源:在 MES 界面手动"审核"同步单,下一轮(≤5分钟)会被星辰状态覆盖。

**列表排序**:`asp_time1` 固定写星辰创建时间(创建留痕),MES"最新创建在前"排序稳定。

## 8. 常见问题(全部为实测踩坑)

| 现象 | 原因与处理 |
|---|---|
| 签名不匹配/401 | 确认 clientSecret 为最新(后台可"重新生成");可跑 `node _verify-signature.mjs` 自证算法 |
| `1030002006 授权密钥校验失败` | 账套重新授权后 appSecret 已变,更新 config.json |
| token 相关异常 | 删除 state.json 强制重取(缓存约 23h,正常无需干预) |
| `HTTP 429 已被限流` | 超出 500 次/分钟,等下一周期;频繁出现则加大任务间隔 |
| 计划任务 LastResult=1 且无日志 | 任务动作经 cmd/bat + 路径含括号 → 改用 run-hidden.vbs 方案(本文档第 6 节) |
| 自写 bat 报"不是内部或外部命令"碎片 | bat 必须 CRLF+ASCII(LF 会被 cmd 错位解析) |
| 每 5 分钟弹黑窗 | 任务用了控制台动作 → 用 run-hidden.vbs 隐藏启动(本文档第 6 节) |
| SQL 连接失败 | 检查 1433 端口/防火墙/账号;本地实例 encrypt 保持 false |
| 税率字段口径存疑 | 星辰 cess 为百分点数值(13 表示 13%);拉到真实单后 dry-run 核对一次 |
| 想立即刷新全部 | 每次运行本就是全量拉取+幂等写入,手动 `Start-ScheduledTask JdySalOrderSync` 或 `node sync.mjs` 即可 |

**沙箱 → 正式切换**(拿到正式 appKey/appSecret 后):改 `config.json` 的 appKey/appSecret →
删除 `state.json` → 下一跳自动全量拉取真实订单。
**清理沙箱测试数据**(可选,在正式数据接入前执行;`外部数据ID IS NOT NULL` 即已同步行):

```sql
DELETE FROM bl_so_order WHERE 单据编号 IN (SELECT 单据编号 FROM bd_so_order WHERE 外部数据ID IS NOT NULL);
DELETE FROM bd_so_order WHERE 外部数据ID IS NOT NULL;
```

## 9. 安全要点(对应金蝶开放平台安全规范)

- 密钥/连接信息只放 `config.json`,已 gitignore,**严禁硬编码进代码或提交仓库**;
- `clientSecret`/`appSecret` 泄露时立即到开发者后台"重新生成";
- 沙箱数据定期清理、限额 100 条,仅用于联调,勿当业务数据;
- 日志只记运行锚点(条数/单号/结果),不打印全量报文。
