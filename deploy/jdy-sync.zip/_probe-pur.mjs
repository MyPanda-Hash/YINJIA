// _probe-pur.mjs — 探测金蝶采购单接口路径与字段(不写库)
import { readFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchAppToken, kingdeeGet } from './kingdee-client.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const readText = (p) => readFileSync(p, 'utf8').replace(/^\uFEFF/, '');
const cfg = JSON.parse(readText(join(HERE, 'config.json')));

const candidates = ['/jdy/v2/scm/pur_order', '/jdy/v2/scm/purchase_order', '/jdy/v2/scm/pur_order_list'];
const { token } = await fetchAppToken(cfg.kingdee);
console.log('token ok');
for (const path of candidates) {
  try {
    const data = await kingdeeGet(cfg.kingdee, token, path, { page: '1', page_size: '2' });
    console.log(`\n=== ${path} OK, count=${data.count} ===`);
    const rows = data.rows || [];
    if (rows.length) {
      console.log('LIST row keys:', Object.keys(rows[0]).join(', '));
      try {
        const d = await kingdeeGet(cfg.kingdee, token, path + '_detail', { id: rows[0].id });
        console.log('\nDETAIL keys:', Object.keys(d).join(', '));
        console.log('material_entity[0] keys:', d.material_entity && d.material_entity[0] ? Object.keys(d.material_entity[0]).join(', ') : '(无)');
        console.log('\nDETAIL sample:', JSON.stringify(d).slice(0, 1500));
      } catch (e) { console.log('detail fail:', e.message); }
    }
    break;
  } catch (e) { console.log(`${path} => ${e.message.split('\n')[0]}`); }
}
