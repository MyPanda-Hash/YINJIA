Dim sh, rc
Set sh = CreateObject("WScript.Shell")
rc = sh.Run("""C:\nvm4w\nodejs\node.exe"" ""D:\jdy-sync\sync.mjs""", 0, True)
WScript.Quit rc