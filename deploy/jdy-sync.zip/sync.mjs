#!/usr/bin/env node
// 金蝶云·星辰 销售订单 → YINJIA-MES 销售订单(bd_so_order/bl_so_order) 定时同步
//
// 用法:
//   node sync.mjs --probe              验证凭证:取app-token+拉1单+详情并打印(不连数据库,无需 npm install)
//   node sync.mjs --dry-run            完整拉取+映射但不写库,打印每单映射结果
//   node sync.mjs                      正式同步(写 SQL Server,需先 npm install + 执行加列迁移SQL)
//   node sync.mjs --config=D:\path\config.json   指定配置文件(默认同目录 config.json)
//
// 设计要点:
//   拉取  : 每次全量拉取已审核单(星辰列表接口时间窗过滤实测不可靠,会漏单),分页 page_size/maxPages 可调
//   幂等  : bd_so_order.外部数据ID 存星辰单据id 并建唯一索引;已存在则更新,行表按单据编号先删后插
//   单号  : 直接沿用星辰 bill_no 作为本地 单据编号(与既有 SO- 前缀单号天然不冲突)
//   状态  : 默认拉全部状态单据,C→已审核,其余→草稿;若只想同步已审核,config.sync.billStatus 设为 "C"
//   限流  : 账套级 500次/分钟;app-token 缓存24小时(接口本身限频2次/分钟)
import { readFileSync, writeFileSync, appendFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { fetchAppToken, kingdeeGet } from './kingdee-client.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const SAL_ORDER_LIST = '/jdy/v2/scm/sal_order';
const SAL_ORDER_DETAIL = '/jdy/v2/scm/sal_order_detail';
const PUR_ORDER_LIST = '/jdy/v2/scm/pur_order';
const PUR_ORDER_DETAIL = '/jdy/v2/scm/pur_order_detail';

// ---------- 参数与配置 ----------
const args = process.argv.slice(2);
const argOf = (name) => { const a = args.find((x) => x.startsWith(`--${name}=`)); return a ? a.split('=').slice(1).join('=') : undefined; };
const has = (name) => args.includes(`--${name}`);

const configPath = argOf('config') || join(HERE, 'config.json');
if (!existsSync(configPath)) {
  console.error(`✗ 未找到配置文件 ${configPath}\n  请复制 config.example.json 为 config.json 并填入凭证/数据库信息`);
  process.exit(1);
}
// 读取文本统一剥 BOM(兼容 PowerShell Set-Content -Encoding UTF8 写出的带 BOM 文件)
const readText = (p) => readFileSync(p, 'utf8').replace(/^\uFEFF/, '');
const cfg = JSON.parse(readText(configPath));
const opt = { billStatus: '', pageSize: 100, maxPages: 50, ...cfg.sync };

const statePath = join(HERE, 'state.json');
const state = existsSync(statePath) ? JSON.parse(readText(statePath)) : {};

// ---------- 工具 ----------
// 日志双写:控制台 + sync.log(计划任务直接以 node.exe 为动作、无控制台重定向,脚本自记日志)
const log = (msg) => {
  const line = `[${new Date().toISOString().replace('T', ' ').slice(0, 19)}] ${msg}`;
  console.log(line);
  try { appendFileSync(join(HERE, 'sync.log'), line + '\n', 'utf8'); } catch { /* 日志失败不影响业务 */ }
};
const str = (v) => (v === undefined || v === null || v === '' ? null : String(v));
const num = (v) => (v === undefined || v === null || v === '' ? null : Number(v));
const nowLocal = () => new Date().toISOString().slice(0, 19).replace('T', ' ');
const N_SYNC_USER = '金蝶同步'; // 星辰审核人缺失时 yj_doc_status.shr 的兜底留痕
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- app-token(缓存24小时) ----------
async function getToken() {
  if (state.appToken && state.appTokenExpireAt && Date.now() < state.appTokenExpireAt) return state.appToken;
  const { token } = await fetchAppToken(cfg.kingdee);
  state.appToken = token;
  state.appTokenExpireAt = Date.now() + 23 * 3600 * 1000; // 留1小时余量
  saveState();
  log(`app-token 已刷新(缓存至 ${new Date(state.appTokenExpireAt).toLocaleString()})`);
  return token;
}
function saveState() { writeFileSync(statePath, JSON.stringify(state, null, 2), 'utf8'); }

// ---------- 数据库(单连接池,mssql 懒加载:--probe/--dry-run 无需安装依赖) ----------
let _pool = null;
async function db() {
  if (_pool) return _pool;
  const mssql = (await import('mssql')).default;
  _pool = new mssql.ConnectionPool({
    server: cfg.database.server,
    port: cfg.database.port || 1433,
    database: cfg.database.database,
    user: cfg.database.user,
    password: cfg.database.password,
    options: { encrypt: !!cfg.database.encrypt, trustServerCertificate: true },
  });
  await _pool.connect();
  return _pool;
}
async function dbClose() { if (_pool) { await _pool.close(); _pool = null; } }

/** 本地是否已有该星辰单(外部数据ID 命中,或同单号的历史行) */
async function orderExists(mssql, pool, extId, billNo) {
  const r = new mssql.Request(pool);
  r.input('p_extid', mssql.NVarChar(64), extId);
  r.input('p_no', mssql.NVarChar(200), billNo);
  const rs = await r.query(
    'SELECT COUNT(1) AS n FROM bd_so_order WHERE 外部数据ID=@p_extid OR (外部数据ID IS NULL AND 单据编号=@p_no)');
  return rs.recordset[0].n > 0;
}

/** 单据落库:头表 upsert + 行表先删后插,单事务 */
async function upsertOrder(mssql, pool, head, lines) {
  const tx = new mssql.Transaction(pool);
  await tx.begin();
  try {
    const r = new mssql.Request(tx);
    r.input('p_no', mssql.NVarChar(200), head.单据编号);
    r.input('p_date', mssql.NVarChar(20), head.单据日期);
    r.input('p_cust', mssql.NVarChar(200), head.客户);
    r.input('p_custno', mssql.NVarChar(100), head.客户编码);
    r.input('p_settle', mssql.NVarChar(100), head.结算客户);
    r.input('p_dept', mssql.NVarChar(100), head.部门);
    r.input('p_deptleader', mssql.NVarChar(200), head.部门负责人);
    r.input('p_emp', mssql.NVarChar(100), head.业务员);
    r.input('p_proj', mssql.NVarChar(200), head.项目);
    r.input('p_dlv', mssql.NVarChar(20), head.预计交货日期);
    r.input('p_linkman', mssql.NVarChar(200), head.联系人);
    r.input('p_remark', mssql.NVarChar(500), head.备注);
    r.input('p_status', mssql.NVarChar(10), head.单据状态);
    r.input('p_auditor', mssql.NVarChar(50), head.审核人);
    r.input('p_auditdate', mssql.NVarChar(30), head.审核时间);
    r.input('p_extid', mssql.NVarChar(64), head.外部数据ID);
    r.input('p_now', mssql.NVarChar(30), nowLocal());
    r.input('p_ctime', mssql.NVarChar(30), head.创建时间);
    // 头表:命中外部数据ID 或 同单号历史行 → 更新;否则插入(税率%等特殊列名需方括号)
    // asp_time1 = 星辰创建时间(稳定创建留痕,MES 列表按其倒序;缺失时回退不覆盖)
    await r.query(`
      UPDATE bd_so_order SET
        单据编号=@p_no, 单据日期=@p_date, 客户=@p_cust, 客户编码=@p_custno, 结算客户=@p_settle,
        部门=@p_dept, 部门负责人=@p_deptleader, 业务员=@p_emp, 项目=@p_proj, 预计交货日期=@p_dlv,
        联系人=@p_linkman, 备注=@p_remark, 单据状态=@p_status, 审核人=@p_auditor, 审核时间=@p_auditdate,
        asp_user1=N'jdy-sync', asp_time1=COALESCE(@p_ctime, asp_time1), asp_cancel=N'N', 外部数据ID=@p_extid
      WHERE 外部数据ID=@p_extid OR (外部数据ID IS NULL AND 单据编号=@p_no);
      IF @@ROWCOUNT = 0
        INSERT INTO bd_so_order (单据编号,单据日期,客户,客户编码,结算客户,部门,部门负责人,业务员,项目,
          预计交货日期,联系人,备注,单据状态,审核人,审核时间,asp_user1,asp_time1,asp_cancel,外部数据ID,外部单据号)
        VALUES (@p_no,@p_date,@p_cust,@p_custno,@p_settle,@p_dept,@p_deptleader,@p_emp,@p_proj,
          @p_dlv,@p_linkman,@p_remark,@p_status,@p_auditor,@p_auditdate,N'jdy-sync',COALESCE(@p_ctime,@p_now),N'N',@p_extid,@p_no);
      DELETE FROM bl_so_order WHERE 单据编号=@p_no;`);
    // 审核状态镜像到 MES 工作流注册表(yj_doc_status):
    // 已审核→shr/shsj=星辰审核人/审核时间;未审核→置空(弃审);单据关闭→已中止
    r.input('p_shr', mssql.NVarChar(50), head.单据状态 === '已审核' ? (head.审核人 || N_SYNC_USER) : null);
    r.input('p_shsj', mssql.NVarChar(30), head.单据状态 === '已审核' ? head.审核时间 : null);
    r.input('p_stopped', mssql.NVarChar(1), head.已关闭 ? 'Y' : 'N');
    await r.query(`
      MERGE yj_doc_status AS t USING (VALUES (N'SO_ORDER', @p_no)) AS s(panel_code, doc_no)
      ON t.panel_code = s.panel_code AND t.doc_no = s.doc_no
      WHEN MATCHED THEN UPDATE SET
        shr = @p_shr, shsj = @p_shsj, canceled = N'N', stopped = @p_stopped, pending = N'N', update_at = GETDATE()
      WHEN NOT MATCHED THEN INSERT (panel_code, doc_no, shr, shsj, canceled, stopped, pending, update_at)
        VALUES (s.panel_code, s.doc_no, @p_shr, @p_shsj, N'N', @p_stopped, N'N', GETDATE());`);
    for (const l of lines) {
      const lr = new mssql.Request(tx);
      lr.input('l_no', mssql.NVarChar(100), l.单据编号);
      lr.input('l_brand', mssql.NVarChar(200), l.品牌);
      lr.input('l_name', mssql.NVarChar(200), l.存货名称);
      lr.input('l_code', mssql.NVarChar(100), l.存货编码);
      lr.input('l_model', mssql.NVarChar(200), l.规格型号);
      lr.input('l_qty', mssql.Decimal(18, 4), l.数量);
      lr.input('l_unit', mssql.NVarChar(100), l.销售单位);
      lr.input('l_price', mssql.Decimal(18, 4), l.单价);
      lr.input('l_cess', mssql.Decimal(18, 4), l.税率);
      lr.input('l_tprice', mssql.Decimal(18, 4), l.含税单价);
      lr.input('l_amount', mssql.Decimal(18, 4), l.金额);
      lr.input('l_tamount', mssql.Decimal(18, 4), l.含税金额);
      lr.input('l_dis', mssql.Decimal(18, 4), l.折扣金额);
      lr.input('l_dlv', mssql.NVarChar(20), l.预计交货日期);
      lr.input('l_stock', mssql.Decimal(18, 4), l.现存量);
      lr.input('l_remark', mssql.NVarChar(200), l.备注);
      lr.input('l_now', mssql.NVarChar(30), nowLocal());
      await lr.query(`INSERT INTO bl_so_order (单据编号,品牌,存货名称,存货编码,规格型号,数量,销售单位,单价,[税率%],
        含税单价,金额,含税金额,折扣金额,预计交货日期,现存量,备注,asp_user1,asp_time1,asp_cancel)
        VALUES (@l_no,@l_brand,@l_name,@l_code,@l_model,@l_qty,@l_unit,@l_price,@l_cess,
        @l_tprice,@l_amount,@l_tamount,@l_dis,@l_dlv,@l_stock,@l_remark,N'jdy-sync',@l_now,N'N');`);
    }
    await tx.commit();
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

// ---------- 拉取 ----------
// 全量扫描模式:实测星辰列表接口的 modify_*_time 时间窗过滤不可靠(窗口内的单据会漏),
// 改为每次拉全部已审核单,靠 外部数据ID 幂等去重(重拉=覆盖更新,不产生重复)
async function listOrders(token, listPath = SAL_ORDER_LIST, tag = '销') {
  const rows = [];
  for (let page = 1; page <= opt.maxPages; page++) {
    const data = await kingdeeGet(cfg.kingdee, token, listPath, {
      bill_status: opt.billStatus,
      page: String(page),
      page_size: String(opt.pageSize),
    });
    for (const r of data.rows || []) rows.push(r);
    const totalPage = Number(data.total_page || 1);
    log(`[${tag}] 列表第 ${page}/${totalPage} 页,本页 ${(data.rows || []).length} 条,共 ${data.count} 条`);
    if (page >= totalPage) break;
  }
  return rows;
}

async function getOrderDetail(token, id, detailPath = SAL_ORDER_DETAIL) {
  return kingdeeGet(cfg.kingdee, token, detailPath, { id });
}

// ---------- 映射(星辰字段 → 本地中文列) ----------
function mapHead(d) {
  const billStatus = d.bill_status === 'C' ? '已审核' : '草稿';
  const dates = (d.material_entity || []).map((m) => m.delivery_date).filter(Boolean).sort();
  return {
    外部数据ID: str(d.id),
    单据编号: str(d.bill_no),
    单据日期: str(d.bill_date),
    客户: str(d.customer_name),
    客户编码: str(d.customer_number),
    结算客户: str(d.settle_customer_number),
    部门: str(d.dept_name),
    部门负责人: null,
    业务员: str(d.emp_name),
    项目: null,
    预计交货日期: dates[0] || null, // 头表无此字段,取明细最早交货日期
    联系人: str(d.contact_linkman),
    备注: str(d.remark),
    单据状态: billStatus,
    审核人: str(d.auditor_name),
    审核时间: str(d.audit_time),
    审批人: null,
    审批时间: null,
    创建时间: str(d.create_time),                       // asp_time1 用(创建留痕,MES 列表按它倒序)
    已关闭: d.bill_close_state === 'S' || d.bill_close_state === 'H', // 镜像到 yj_doc_status.stopped
  };
}
function mapLines(d) {
  return (d.material_entity || []).map((m) => ({
    单据编号: str(d.bill_no),
    品牌: null,
    存货名称: str(m.material_name),
    存货编码: str(m.material_number),
    规格型号: str(m.material_model),
    数量: num(m.qty),
    销售单位: str(m.unit_name) || str(m.unit_number),
    单价: num(m.price),
    税率: num(m.cess),
    含税单价: num(m.tax_price),
    金额: num(m.amount),
    含税金额: num(m.all_amount),
    折扣金额: num(m.dis_amount),
    预计交货日期: str(m.delivery_date),
    现存量: num(m.inv_qty),
    备注: str(m.comment),
  }));
}

// ---------- 采购单(金蝶 → bd_pu_order/bl_pu_order) ----------
// 字段命名按星辰 V2 SCM 同构约定实现(供应商/到货字段与销售单客户/交货字段对称);
// ⚠ 待沙箱出现首张采购单后以 --dry-run 实数据核对一次映射(README §8 同款验证法)
function mapPurHead(d) {
  return {
    外部数据ID: str(d.id),
    单据编号: str(d.bill_no),
    单据日期: str(d.bill_date),
    供应商: str(d.supplier_name),
    供应商编码: str(d.supplier_number),
    币种: str(d.currency_name),
    汇率: num(d.exchange_rate),
    到货地址: str(d.delivery_address) || str(d.arrival_address),
    交货日期: str(d.delivery_date),
    备注: str(d.remark),
    单据状态: d.bill_status === 'C' ? '已审核' : '草稿',
    审核人: str(d.auditor_name),
    审核时间: str(d.audit_time),
    创建时间: str(d.create_time),
    已关闭: d.bill_close_state === 'S' || d.bill_close_state === 'H',
  };
}
function mapPurLines(d) {
  return (d.material_entity || []).map((m) => ({
    单据编号: str(d.bill_no),
    物料编码: str(m.material_number),
    物料名称: str(m.material_name),
    规格型号: str(m.material_model),
    单位: str(m.unit_name) || str(m.unit_number),
    数量: num(m.qty),
    单价: num(m.price),
    金额: num(m.amount),
    税率: num(m.cess),
    含税单价: num(m.tax_price),
    含税金额: num(m.all_amount),
    折扣金额: num(m.dis_amount),
    预计到货日期: str(m.arrival_date) || str(m.delivery_date),
    仓库: str(m.stock_name) || str(m.warehouse_name),
    现存量: num(m.inv_qty),
    备注: str(m.comment),
  }));
}

async function purOrderExists(mssql, pool, extId, billNo) {
  const r = new mssql.Request(pool);
  r.input('p_extid', mssql.NVarChar(64), extId);
  r.input('p_no', mssql.NVarChar(200), billNo);
  const rs = await r.query(
    'SELECT COUNT(1) AS n FROM bd_pu_order WHERE 外部数据ID=@p_extid OR (外部数据ID IS NULL AND 单据编号=@p_no)');
  return rs.recordset[0].n > 0;
}

async function upsertPurOrder(mssql, pool, head, lines) {
  const tx = new mssql.Transaction(pool);
  await tx.begin();
  try {
    const r = new mssql.Request(tx);
    r.input('p_no', mssql.NVarChar(200), head.单据编号);
    r.input('p_date', mssql.NVarChar(20), head.单据日期);
    r.input('p_supp', mssql.NVarChar(200), head.供应商);
    r.input('p_suppno', mssql.NVarChar(100), head.供应商编码);
    r.input('p_cur', mssql.NVarChar(50), head.币种);
    r.input('p_rate', mssql.Decimal(18, 4), head.汇率);
    r.input('p_addr', mssql.NVarChar(500), head.到货地址);
    r.input('p_dlv', mssql.NVarChar(20), head.交货日期);
    r.input('p_remark', mssql.NVarChar(500), head.备注);
    r.input('p_status', mssql.NVarChar(10), head.单据状态);
    r.input('p_auditor', mssql.NVarChar(50), head.审核人);
    r.input('p_auditdate', mssql.NVarChar(30), head.审核时间);
    r.input('p_extid', mssql.NVarChar(64), head.外部数据ID);
    r.input('p_now', mssql.NVarChar(30), nowLocal());
    r.input('p_ctime', mssql.NVarChar(30), head.创建时间);
    await r.query(`
      UPDATE bd_pu_order SET
        单据编号=@p_no, 单据日期=@p_date, 供应商=@p_supp, 供应商编码=@p_suppno, 币种=@p_cur, 汇率=@p_rate,
        到货地址=@p_addr, 交货日期=@p_dlv, 备注=@p_remark, 单据状态=@p_status, 审核人=@p_auditor, 审核时间=@p_auditdate,
        数据来源=N'金蝶同步', asp_user1=N'jdy-sync', asp_time1=COALESCE(@p_ctime, asp_time1), asp_cancel=N'N', 外部数据ID=@p_extid
      WHERE 外部数据ID=@p_extid OR (外部数据ID IS NULL AND 单据编号=@p_no);
      IF @@ROWCOUNT = 0
        INSERT INTO bd_pu_order (单据编号,单据日期,供应商,供应商编码,币种,汇率,到货地址,交货日期,备注,
          单据状态,审核人,审核时间,数据来源,asp_user1,asp_time1,asp_cancel,外部数据ID,外部单据号)
        VALUES (@p_no,@p_date,@p_supp,@p_suppno,@p_cur,@p_rate,@p_addr,@p_dlv,@p_remark,
          @p_status,@p_auditor,@p_auditdate,N'金蝶同步',N'jdy-sync',COALESCE(@p_ctime,@p_now),N'N',@p_extid,@p_no);
      DELETE FROM bl_pu_order WHERE 单据编号=@p_no;`);
    r.input('p_shr', mssql.NVarChar(50), head.单据状态 === '已审核' ? (head.审核人 || N_SYNC_USER) : null);
    r.input('p_shsj', mssql.NVarChar(30), head.单据状态 === '已审核' ? head.审核时间 : null);
    r.input('p_stopped', mssql.NVarChar(1), head.已关闭 ? 'Y' : 'N');
    await r.query(`
      MERGE yj_doc_status AS t USING (VALUES (N'PU_ORDER', @p_no)) AS s(panel_code, doc_no)
      ON t.panel_code = s.panel_code AND t.doc_no = s.doc_no
      WHEN MATCHED THEN UPDATE SET
        shr = @p_shr, shsj = @p_shsj, canceled = N'N', stopped = @p_stopped, pending = N'N', update_at = GETDATE()
      WHEN NOT MATCHED THEN INSERT (panel_code, doc_no, shr, shsj, canceled, stopped, pending, update_at)
        VALUES (s.panel_code, s.doc_no, @p_shr, @p_shsj, N'N', @p_stopped, N'N', GETDATE());`);
    for (const l of lines) {
      const lr = new mssql.Request(tx);
      lr.input('l_no', mssql.NVarChar(100), l.单据编号);
      lr.input('l_code', mssql.NVarChar(100), l.物料编码);
      lr.input('l_name', mssql.NVarChar(200), l.物料名称);
      lr.input('l_model', mssql.NVarChar(200), l.规格型号);
      lr.input('l_unit', mssql.NVarChar(100), l.单位);
      lr.input('l_qty', mssql.Decimal(18, 4), l.数量);
      lr.input('l_price', mssql.Decimal(18, 4), l.单价);
      lr.input('l_amount', mssql.Decimal(18, 4), l.金额);
      lr.input('l_cess', mssql.Decimal(18, 4), l.税率);
      lr.input('l_tprice', mssql.Decimal(18, 4), l.含税单价);
      lr.input('l_tamount', mssql.Decimal(18, 4), l.含税金额);
      lr.input('l_dis', mssql.Decimal(18, 4), l.折扣金额);
      lr.input('l_arrival', mssql.NVarChar(20), l.预计到货日期);
      lr.input('l_stock', mssql.NVarChar(100), l.仓库);
      lr.input('l_invqty', mssql.Decimal(18, 4), l.现存量);
      lr.input('l_remark', mssql.NVarChar(200), l.备注);
      lr.input('l_now', mssql.NVarChar(30), nowLocal());
      await lr.query(`INSERT INTO bl_pu_order (单据编号,物料编码,物料名称,规格型号,单位,数量,单价,金额,[税率%],
        含税单价,含税金额,折扣金额,预计到货日期,仓库,现存量,备注,asp_user1,asp_time1,asp_cancel)
        VALUES (@l_no,@l_code,@l_name,@l_model,@l_unit,@l_qty,@l_price,@l_amount,@l_cess,
        @l_tprice,@l_tamount,@l_dis,@l_arrival,@l_stock,@l_invqty,@l_remark,N'jdy-sync',@l_now,N'N');`);
    }
    await tx.commit();
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

// ---------- 主流程 ----------
async function main() {
  const token = await getToken();
  log(`app-token 就绪(${token.slice(0, 6)}...)`);

  if (has('probe')) {
    for (const [tag, listPath, detailPath, mh, ml] of [
      ['销', SAL_ORDER_LIST, SAL_ORDER_DETAIL, mapHead, mapLines],
      ['采', PUR_ORDER_LIST, PUR_ORDER_DETAIL, mapPurHead, mapPurLines],
    ]) {
      const data = await kingdeeGet(cfg.kingdee, token, listPath, {
        bill_status: opt.billStatus, page: '1', page_size: '1',
      });
      if (!(data.rows || []).length) { log(`probe[${tag}]:该账套当前条件下没有订单(连接与认证均正常)`); continue; }
      const d = await getOrderDetail(token, data.rows[0].id, detailPath);
      console.log(`===== [${tag}] 映射示例 =====`);
      console.log(JSON.stringify({ 头: mh(d), 行: ml(d) }, null, 2));
      log(`probe[${tag}] 完成:认证、列表、详情、字段映射全链路正常`);
    }
    return;
  }

  let exitFail = false;
  for (const [tag, listPath, detailPath, mh, ml, exists, upsert] of [
    ['销', SAL_ORDER_LIST, SAL_ORDER_DETAIL, mapHead, mapLines, orderExists, upsertOrder],
    ['采', PUR_ORDER_LIST, PUR_ORDER_DETAIL, mapPurHead, mapPurLines, purOrderExists, upsertPurOrder],
  ]) {
    const rows = await listOrders(token, listPath, tag);
    log(`[${tag}] 共拉到 ${rows.length} 张订单,开始逐单处理`);

    let inserted = 0, updated = 0, failed = 0;
    try {
      for (const row of rows) {
        try {
          const d = await getOrderDetail(token, row.id, detailPath);
          const head = mh(d);
          const lines = ml(d);
          if (has('dry-run')) {
            console.log(`[${tag}] —— ${head.单据编号} 状态=${head.单据状态} 行数=${lines.length}`);
            console.log(JSON.stringify({ 头: head, 行: lines.slice(0, 3) }, null, 2));
            continue;
          }
          const mssql = (await import('mssql')).default;
          const pool = await db();
          const known = await exists(mssql, pool, head.外部数据ID, head.单据编号);
          await upsert(mssql, pool, head, lines);
          known ? updated++ : inserted++;
          log(`[${tag}] ${known ? '更新' : '新增'} ${head.单据编号}(${lines.length} 行)`);
        } catch (e) {
          failed++;
          log(`[${tag}] ✗ 单据 ${row.bill_no || row.id} 处理失败: ${e.message}`);
        }
      }
    } finally {
      await dbClose();
    }
    log(`[${tag}] 完成:新增 ${inserted},更新 ${updated},失败 ${failed}${has('dry-run') ? '(dry-run 未写库)' : ''}`);
    if (failed > 0) exitFail = true;
  }

  if (!has('dry-run')) {
    state.lastSyncMs = Date.now(); // 仅作"上次运行"时间参考,不再参与过滤
    saveState();
  }
  if (exitFail) process.exitCode = 2;
}

main().catch((e) => { console.error(`✗ 同步失败: ${e.message}`); process.exit(1); });
