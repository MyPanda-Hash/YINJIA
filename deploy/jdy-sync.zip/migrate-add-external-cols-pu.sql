-- =====================================================================
-- 金蝶云·星辰采购单同步:bd_pu_order 增加外部数据锚点列(幂等,可重复执行)
-- 与 migrate-add-external-cols.sql(销售订单)同模式
-- =====================================================================

IF COL_LENGTH('dbo.bd_pu_order', '外部数据ID') IS NULL
    ALTER TABLE dbo.bd_pu_order ADD [外部数据ID] nvarchar(64) NULL;

IF COL_LENGTH('dbo.bd_pu_order', '外部单据号') IS NULL
    ALTER TABLE dbo.bd_pu_order ADD [外部单据号] nvarchar(200) NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_bd_pu_order_ext_id')
    CREATE UNIQUE INDEX ux_bd_pu_order_ext_id
        ON dbo.bd_pu_order ([外部数据ID])
        WHERE [外部数据ID] IS NOT NULL;
GO

SELECT N'bd_pu_order 外部数据ID' AS 项, CASE WHEN COL_LENGTH('dbo.bd_pu_order', N'外部数据ID') IS NOT NULL THEN 1 ELSE 0 END AS 已就绪
UNION ALL
SELECT N'bd_pu_order 外部单据号', CASE WHEN COL_LENGTH('dbo.bd_pu_order', N'外部单据号') IS NOT NULL THEN 1 ELSE 0 END
UNION ALL
SELECT N'唯一索引 ux_bd_pu_order_ext_id', CASE WHEN INDEXPROPERTY(OBJECT_ID('dbo.bd_pu_order'), 'ux_bd_pu_order_ext_id', 'IndexID') IS NOT NULL THEN 1 ELSE 0 END;
